var rest = require('restler');
var wso2config = require("./config");
var constants = require('constants');
var ClientOAuth2 = require('client-oauth2');

require("ssl-root-cas").inject();

var wso2Auth = new ClientOAuth2({
  clientId: wso2config.clientId,
  clientSecret: wso2config.clientSecret,
  accessTokenUri: wso2config.token.host+"/"+wso2config.token.path,
  authorizationUri: wso2config.authUrl,
  redirectUri: wso2config.redirect_uri,
  scopes: ['apim:subscribe', 'subscribe',"openid"]
})

module.exports = {
	authOpenID : function( code, callback){
		rest.post(wso2config.token.host+"/"+wso2config.token.path, {
		  username: wso2config.clientId,
		  password: wso2config.clientSecret,
		  data: {
		  	code:code,
		  	grant_type:"authorization_code",
		  	redirect_uri:wso2config.redirect_uri
		  }
		}).on('complete', function(data) {
		  // console.log(data);
			if(data.error)
				callback(data,null);
			else{
				callback(null,{
					openid_data:data
				});
		  }
		});

	},
	authorizeUrl : function(){
		return wso2Auth.code.getUri();
	},
	authAnonymous : function(callback){
		rest.post(wso2config.token.host+"/"+wso2config.token.path, {
		  username: wso2config.clientId,
		  password: wso2config.clientSecret,
		  data: {
		  	username:wso2config.anonymousUser.username,
		  	password:wso2config.anonymousUser.password,
		  	grant_type:"password",
		  	redirect_uri:wso2config.redirect_uri,
		  	scope:"apim:subscribe"
		  }
		}).on('complete', function(data) {
		  // console.log(data);
			if(data.error)
				callback(data,null);
			else{
				data.anonym = true;
				callback(null,{
					openid_data:data
				});
		  }
		});
	},
	authLogin : function(username,password,callback){
		rest.post(wso2config.token.host+"/"+wso2config.token.path, {
		  username: wso2config.clientId,
		  password: wso2config.clientSecret,
		  data: {
		  	username:username,
		  	password:password,
		  	grant_type:"password",
		  	redirect_uri:wso2config.redirect_uri,
		  	scope:"apim:subscribe:"
		  }
		}).on('complete', function(data) {
			if(data.error)
				callback(data,null);
			else{
				data.anonym = false;
				callback(null,{
					openid_data:data
				});
		  }
		});
	},
	refreshToken: function(openid_data,callback){
		rest.post(wso2config.token.host+"/"+wso2config.token.path, {
		  username: wso2config.clientId,
		  password: wso2config.clientSecret,
		  data: {
		  	clientId:wso2config.clientId,
		  	clientSecret:wso2config.clientSecret,
		  	grant_type:"refresh_token",
		  	refresh_token:openid_data.refresh_token,
		  	scope:"apim:subscribe"
		  }
		}).on('complete', function(data) {
			if(data.error)
				callback(data,null);
			else{
				data.anonym = true;
				callback(null,{
					openid_data:data
				});
		  }
		});
	},
	userInfo:function(openid_data,callback){
		rest.get(wso2config.profileUrl, {
		headers:{
			'Authorization':openid_data.open_id.token_type+" "+openid_data.open_id.access_token
		}
		}).on('complete', function(data) {
			if(!data.sub){
				callback(data);
			}
			else{
				data.sub = data.sub.replace("@carbon.super","");
				callback(null,data)

			}
		});
	}
}