var rest = require('restler');
var wso2config = require("./config");
var querystring = require("querystring");
var restSync = require("inline-rest");
var entity = require(__base + "entities");
var async = require("async");
var apis = require("./apis");
var application = require("./applications");

var getByApi = function(apiId, param, options, callback) {
    var opt = {
        open_id: false,
    }
    var par = {
        query: "*",
        limit: 5,
        offset: 0
    }
    if (param)
        for (p in param)
            par[p] = param[p];


    for (p in options)
        opt[p] = options[p];

    if (opt.open_id) {
        var url = wso2config.apiPath + "/" + wso2config.version + "/subscriptions";
        param["apiId"] = apiId;
        param = querystring.stringify(param);
        var result = [];
        rest.get(url + "?" + param, {
            headers: {
                'Authorization': opt.open_id.token_type + " " + opt.open_id.access_token
            }
        }).on("complete", function(data) {
            if (data.error) {
                callback(data);
                return;
            }

            callback(null, data);
        });
    }
}
var getByApp = function(applicationId, param, options, callback) {
    var opt = {
        open_id: false,
    }
    var par = {
        query: "*",
        limit: 5,
        offset: 0
    }
    if (param)
        for (p in param)
            par[p] = param[p];


    for (p in options)
        opt[p] = options[p];

    if (opt.open_id) {
        var url = wso2config.apiPath + "/" + wso2config.version + "/subscriptions";
        param["applicationId"] = applicationId;
        param["limit"] = 99999;
        param = querystring.stringify(param);
        var result = [];
        application.get(applicationId, opt, function(err, app) {

            if (err)
                callback(err);
            else {
                rest.get(url + "?" + param, {
                    headers: {
                        'Authorization': opt.open_id.token_type + " " + opt.open_id.access_token
                    }
                }).on("complete", function(data) {
                    if (data.error) {
                        callback(data);
                        return;
                    }
                    var q = async.queue(function(subscription, c) {
                        if(subscription.applicationId == applicationId){
                            var apiIdentifier = subscription.apiIdentifier.replace("@", "-AT-");
                            apis.get(apiIdentifier, opt, function(err, api) {
                                if (err)
                                    c(null);
                                else {

                                    c(new entity.Subscription({
                                        subscriptionId: subscription.subscriptionId,
                                        api: api,
                                        application: app
                                    }));
                                }
                            });
                        }
                        else
                            c(null);
                        // c(subscription);
                    }, 2);

                    var result = [];
                    // assign a callback
                    q.drain = function() {
                        callback(null, { next: data.next, subscription: result, prev: data.previous });
                    };
                    q.push(data.list, function(subscription) {
                        if (subscription != null)
                            result.push(subscription);
                    });
                    // callback(null,data);
                });
            }
        });

    }
}
var getAll = function(options, callback) {
    var opt = {
        open_id: false,
    }
    for (p in options)
        opt[p] = options[p];

    application.getAll({}, opt, function(err, data) {
        var q = async.queue(function(app, c) {
            getByApp(app.applicationId, {}, opt, function(err, subs) {
                c(subs);
            })
        }, 2);
        var result = [];
        // assign a callback
        q.drain = function() {
            callback(null, result);
        };
        q.push(data.applications, function(subscription) {
            if (subscription != null)
                for (ind in subscription.subscription)
                    result.push(subscription.subscription[ind]);
        });
    });
}
var get = function(subscriptionId, options, callback) {
    var opt = {
        open_id: false
    }
    for (p in options)
        opt[p] = options[p];

    if (opt.open_id) {
        var url = wso2config.apiPath + "/" + wso2config.version + "/subscriptions/" + subscriptionId;
        rest.get(url, {
            headers: {
                'Authorization': opt.open_id.token_type + " " + opt.open_id.access_token
            }
        }).
        on("complete", function(res) {
            callback(false, res);
        });
    }
}

var subscribe = function(applicationId, apiIdentifier, tier, options, callback) {
    var opt = {
        open_id: false
    }
    apiIdentifier = apiIdentifier.replace("@", "-AT-");

    for (p in options)
        opt[p] = options[p];

    if (opt.open_id) {
        var url = wso2config.apiPath + "/" + wso2config.version + "/subscriptions/";
        rest.post(url, {
            data: { applicationId: applicationId, apiIdentifier: apiIdentifier, tier: tier },
            headers: {
                'Authorization': opt.open_id.token_type + " " + opt.open_id.access_token
            }
        }).
        on("complete", function(res) {
            callback(false, res);
        });
    }
}
var remove = function(subscriptionId, options, callback) {
    var opt = {
        open_id: false
    }
    for (p in options)
        opt[p] = options[p];

    if (opt.open_id) {
        var url = wso2config.apiPath + "/" + wso2config.version + "/subscriptions/" + subscriptionId;
        rest.del(url, {
            headers: {
                'Authorization': opt.open_id.token_type + " " + opt.open_id.access_token
            }
        }).
        on("complete", function(res) {
            callback(false, res);
        });
    }
}
module.exports = {
    getByApp: getByApp,
    getByApi: getByApi,
    get: get,
    remove: remove,
    subscribe: subscribe,
    getAll: getAll
}