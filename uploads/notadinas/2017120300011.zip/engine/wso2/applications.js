var rest = require('restler');
var wso2config = require("./config");
var querystring = require("querystring");
var restSync = require("inline-rest");
var entity= require(__base+"entities");
var async = require("async");

var getAll = function(param,options,callback){
	var opt = {
		open_id : false,
	}
	var par = {
		query:"*",
		limit:5,
		offset:0
	}
	if(param){
		for(p in param){
			if(p == "name")
				par["query"] = param[p]
			else 
				par[p] = param[p];
		}
	}

	for(p in options)
		opt[p] = options[p];
	
	if(opt.open_id){

		var url = wso2config.apiPath+"/"+wso2config.version+"/applications";
		param = querystring.stringify(param);
		var result =[];
		rest.get(url+"?"+param,{
			headers:{
				'Authorization':opt.open_id.token_type+" "+opt.open_id.access_token
			}
		}).on("complete",function(data){
			if (data.error){
				callback(data);
				return;
			}
			var result = [];
			for (var i = 0; i < data.list.length; i++) {
				var app = data.list[i];
				app.name = app.name.replace(app.applicationId,"");
				app.name = app.name.replace(app.applicationId,"");
				app.name = app.name.replace(app.applicationId,"");
				result.push(new entity.Application({
					groupId:app.groupId,
					subscriber: app.subscriber,
					throttlingTier: app.throttlingTier,
					applicationId: app.applicationId,
					description: app.description,
					status: app.status,
					name: app.name
				}));
			}
			callback(null,{next:data.next,applications:result,prev:data.previous});
		});
	}
}
var get = function(id,options,callback){
	var opt = {
		open_id:false
	}
	for(p in options)
		opt[p] = options[p];
	if(opt.open_id){
		var url = wso2config.apiPath+"/"+wso2config.version+"/applications/"+id;
		rest.get(url,{
			headers:{
				'Authorization':opt.open_id.token_type+" "+opt.open_id.access_token
			}
		}).
		on("complete",function(app){
			if(app.error){
				callback(app);
				return;
			}
			console.log(app.name);
			var application = new entity.Application({
					groupId:app.groupId,
					subscriber: app.subscriber,
					throttlingTier: app.throttlingTier,
					applicationId: app.applicationId,
					description: app.description,
					status: app.status,
					name: app.name,
					keys:app.keys
			})
			update(application,options,function(err,data){
				if(err){
					callback(err);
				}
				else{
					application.name = application.name.replace(application.applicationId,"");
					callback(null,application);
				}
			})				
		});
	}
}

var create = function(application, options,callback){
	var opt = {
		open_id:false
	}
	for(p in options)
		opt[p] = options[p];
	if(opt.open_id){	
		var url = wso2config.apiPath+"/"+wso2config.version+"/applications/";
		rest.post(url,{data:JSON.stringify({
				applicationId:application.applicationId,
				groupId: application.groupId,
				callbackUrl: application.callbackUrl,
				throttlingTier: application.throttlingTier, 
				description: application.description, 
				status: application.status,
				name: application.name	
			}),
			headers:{
				'Authorization':opt.open_id.token_type+" "+opt.open_id.access_token,
				"Content-type":"application/json",
				 'Accept': 'application/json'
			}
		}).
		on("complete",function(res,det){			
			
			
			callback(false,res);
		});
	}
}
var update = function(application,options,callback){
	var opt = {
		open_id:false
	}
	for(p in options)
		opt[p] = options[p];

	if(opt.open_id){
		var url = wso2config.apiPath+"/"+wso2config.version+"/applications/"+application.applicationId;
		rest.put(url,{data:JSON.stringify({
				applicationId:application.applicationId,
				groupId: application.groupId,
				callbackUrl: application.callbackUrl,
				throttlingTier: application.throttlingTier, 
				description: application.description, 
				status: application.status,
				name: application.name	
			}),
			headers:{
				'Authorization':opt.open_id.token_type+" "+opt.open_id.access_token,
				"Content-type":"application/json",
				 'Accept': 'application/json'
			}
		}).
		on("complete",function(res,d){
			if(res.error)
				callback(res);
			else
				callback(false,res);
		});
	}
}
var generateKey = function(applicationId,param,options,callback){
		var opt = {
		open_id:false
	}
	for(p in options)
		opt[p] = options[p];

	if(opt.open_id){
		var url = wso2config.apiPath+"/"+wso2config.version+"/applications/generate-keys?applicationId="+applicationId;
		rest.post(url,param,{
			headers:{
				'Authorization':opt.open_id.token_type+" "+opt.open_id.access_token
			}
		}).
		on("complete",function(res){				
			callback(false,res);
		});
	}
}
module.exports ={
	getAll: getAll,
	get: get,
	create: create,
	update: update,
	generateKey: generateKey
}