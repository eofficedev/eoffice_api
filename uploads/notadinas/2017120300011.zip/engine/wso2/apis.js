var rest = require('restler');
var wso2config = require("./config");
var querystring = require("querystring");
var restSync = require("inline-rest");
var entity= require(__base+"entities");
var async = require("async");
var getApi =function(id,options,callback){
	var opt = {
		open_id:false
	}
	for(p in options)
		opt[p] = options[p];
	if(opt.open_id){
		var url = wso2config.apiPath+"/"+wso2config.version+"/apis/"+id;
		rest.get(url,{
			headers:{
				'Authorization':opt.open_id.token_type+" "+opt.open_id.access_token
			}
		}).
		on("complete",function(api){
		// console.log(url,'Authorization: '+opt.open_id.token_type+" "+opt.open_id.access_token);
		if(api.error)
			callback(api);
		else				
			callback(false,new entity.Api({
					id:api.id,
					tags:api.tags,
					tiers:api.tiers,
					name:api.name,
					version:api.version,
					publisher:api.provider,
					thumbnailUrl:api.thumbnailUrl,
					description:api.description
				}));
		});
	}
};
var getAll = function(param,options,callback){
	var opt = {
		open_id : false,
	}
	var par = {
		query:"*",
		limit:5,
		offset:0
	}
	if(param){
		for(p in param){

			if(typeof param[p] =='object' ){
				var arr = [];
				for(o in param[p])
					arr.push(o+":"+param[p][0])
				par[p] = arr.join(";");
			}
			else
				par[p] = param[p];
		}
	}

	for(p in options)
		opt[p] = options[p];
		
	if(opt.open_id){
		var url = wso2config.apiPath+"/"+wso2config.version+"/apis";
		param = querystring.stringify(param);
		var result =[];
		
		rest.get(url+"?"+param,{
			headers:{
				'Authorization':opt.open_id.token_type+" "+opt.open_id.access_token
			}
		}).on("complete",function(data){
			if (data.error){
				callback(data);
				return;
			}

			var q = async.queue(function(api, c) {
			    getApi(api.id,options,function(err,data){
			    	if(!err)
			    		c(data);
			    	else
			    		c(null);
			    });
			    
			}, 2);

			// assign a callback
			q.drain = function() {
				callback(null,{next:data.next,apis:result,prev:data.previous});
			};
			q.push(data.list,function(api){
				// console.log(api);
				if(api!=null)
					result.push(api);
			});
			// callback(null,data);
		});
	}
};

var swagger = function(id,options,callback){
		var opt = {
			open_id:false
		}
		for(p in options)
			opt[p] = options[p];
		if(opt.open_id){
			var url = wso2config.apiPath+"/"+wso2config.version+"/apis/"+id+"/swagger";
			rest.get(url).
			on("complete",function(data){
				callback(false,data);
			});
		}
	}

var getTags = function(options,callback){
	var opt = {
		open_id:false
	}
	for(p in options)
		opt[p] = options[p];

	var url = wso2config.apiPath+"/"+wso2config.version+"/tags/";	
		rest.get(url,{
			headers:{
				'Authorization':opt.open_id.token_type+" "+opt.open_id.access_token
			}
		})
		.on("complete",function(data){
			if(!data.error){
				callback(false,data)
			}
			else
				callback(data);
		});
	
}
var getTiers = function(options,callback){
	
}
module.exports = {
	getAll:getAll,
	get:getApi,
	swagger:swagger,
	getTags : getTags
}