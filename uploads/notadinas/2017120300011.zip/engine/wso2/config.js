module.exports = {
	apiPath 	: "http://192.168.11.3:9763/api/am/store/",
	token 	: {
		host:"https://192.168.11.9:9443/oauth2",
		//host:"https://identity.mainapi.net/",
		path: "token"
	},
	anonymousUser:{
		// username:"everyone@mainapi.net",
		// password:"wN60&z+T`l[0g@R"
		username:"sugianto@ayodiskusi.com",
		password:"sugianto"
	},
	authUrl:"https://identity.mainapi.net/oauth2/authorize",
	profileUrl:"https://192.168.11.9:9443/oauth2/userinfo?schema=openid",
	clientId	: "9TCotL0v3trGeKYgVvlQfBk3dEMa",
	clientSecret: "dMFPZfTukZRLp0k9KKWkDQ_S92ga",
	redirect_uri: "https://beta.mainapi.net/auth/identity/",
	version: "v0.9",
	soap:{
		auth:{
			username:"admin@wso2.com",
			password:"OAMcool!!!"
		}
	},
	billing:{
		
	}

}
