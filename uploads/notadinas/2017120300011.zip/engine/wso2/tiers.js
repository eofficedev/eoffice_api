var rest = require('restler');
var wso2config = require("./config");
var querystring = require("querystring");
var restSync = require("inline-rest");
var entity= require(__base+"entities");
var async = require("async");


exports.getApplicationTiers = function(options,callback){
	 var opt = {
        open_id: false,
    }
	for(p in options)
		opt[p] = options[p];
	if(opt.open_id){

		var url = wso2config.apiPath+"/"+wso2config.version+"/tiers/application";
		rest.get(url,{headers: {
                'Authorization': opt.open_id.token_type + " " + opt.open_id.access_token
            }}).on("success",function(data){
            	console.log(data);
            	if(data.error)
            		callback(data);
            	else{
            		var results = [];
            		for (var i = data.list.length - 1; i >= 0; i--) {
            			var t = data.list[i];
            			var tier = new entity.Tiers({
							name : t.name,
							unitTime: t.unitTime,
							description : t.description,
							stopOnQuotaReach:t.stopOnQuotaReach,
							tierPlan:t.tierPlan,
							tierLevel:t.tierLevel,
							requestCount:t.requestCount,
							attributes:t.attributes

	            		});
	            		results.push(tier);
            		}
            		
            		callback(null,results);
            	}
            });

	}
}

exports.getApiTiers = function(options,callback){
	 var opt = {
        open_id: false,
    }
	for(p in options)
		opt[p] = options[p];
	if(opt.open_id){

		var url = wso2config.apiPath+"/"+wso2config.version+"/tiers/api";
		rest.get(url,{headers: {
                'Authorization': opt.open_id.token_type + " " + opt.open_id.access_token
            }}).on("success",function(data){
            	if(data.error)
            		callback(data);
            	else{
            			var results = [];
            		for (var i = data.list.length - 1; i >= 0; i--) {
            			var t = data.list[i];
            			var tier = new entity.Tiers({
							name : t.name,
							unitTime: t.unitTime,
							description : t.description,
							stopOnQuotaReach:t.stopOnQuotaReach,
							tierPlan:t.tierPlan,
							tierLevel:t.tierLevel,
							requestCount:t.requestCount,
							attributes:t.attributes

	            		});
	            		results.push(tier);
            		}
            		
            		callback(null,results);
            	}
            });
	}
}

exports.details = function(name,options,callback){
	 var opt = {
        open_id: false,
    }
for(p in options)
		opt[p] = options[p];
	if(opt.open_id){

		var url = wso2config.apiPath+"/"+wso2config.version+"/tiers/"+name;
		rest.get(url,{headers: {
                'Authorization': opt.open_id.token_type + " " + opt.open_id.access_token
            }}).on("success",function(t){
            	if(t.error)
            		callback(t);
            	else{
            		callback(null,new entity.Tiers({
            			name : t.name,
						unitTime: t.unitTime,
						description : t.description,
						stopOnQuotaReach:t.stopOnQuotaReach,
						tierPlan:t.tierPlan,
						tierLevel:t.tierLevel,
						requestCount:t.requestCount,
						attributes:t.attributes
            		}));
            	}
            });
	}
}