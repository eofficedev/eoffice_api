var rest = require("restler");

module.exports = {
	post:function(url, param,callback){

	}
}