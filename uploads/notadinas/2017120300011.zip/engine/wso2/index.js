
module.exports = {
	openid: require("./openid"),
	api: require("./apis"),
	user: require("./user"),
	application: require("./applications"),
	subscription: require("./subscriptions"),
	tiers: require("./tiers")
}