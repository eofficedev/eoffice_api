var rest = require('restler');
var wso2config = require("./config");
var querystring = require("querystring");
var xml2js = require("xml2js");

var soap = require('soap');
var wsdl = __dirname + '/soap/service.wsdl';
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0"
// var register = function(userdata, callback) {
//     soap.createClient(wsdl, function(err, client) {
//         if (err) {
//             callback(err);
//             return;
//         }
//         var args = {
//             userName: userdata.username,
//             credential: userdata.password,
//             profileName: "default",
//             roleList: ["Internal/subscriber"],
//             //claims: "<ser:claims><xsd:claimURI>http://wso2.org/claims/givenname</xsd:claimURI><xsd:value>"+userdata.fullname+"</xsd:value></ser:claims>",
//             claims : [{claimURI:"http://wso2.org/claims/givenname",value:userdata.fullname}],
//             requirePasswordChange:false
//         }

//         // var args =  {_xml:'        <ser:userName>test9@mainapi.net</ser:userName>'+
//         //             '         <ser:credential>test123!@#</ser:credential>'+
//         //             '         <ser:roleList>Internal/subscriber</ser:roleList>'+
//         //             '         <ser:claims>'+
//         //             '            <xsd:claimURI>http://wso2.org/claims/givenname</xsd:claimURI>'+
//         //             '            <xsd:value>test4</xsd:value>'+
//         //             '         </ser:claims>'+
//         //             '         <ser:profileName>default</ser:profileName>'+
//         //             '         <ser:requirePasswordChange>false</ser:requirePasswordChange>'
//                 // };
//         client.setSecurity(new soap.BasicAuthSecurity(wso2config.soap.auth.username, wso2config.soap.auth.password));

//         client.addUser(args, function(err, result) {
//             callback(null, result);
//             console.log(client.describe().RemoteUserStoreManagerService.RemoteUserStoreManagerServiceHttpsSoap12Endpoint.addUser);
//             console.log(result);

//         });
//     });
// }
var register = function (userdata,callback){
    var xml = '<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ser="http://service.ws.um.carbon.wso2.org" xmlns:xsd="http://common.mgt.user.carbon.wso2.org/xsd">'+
              '     <soap:Header/>'+
              '     <soap:Body>'+
              '        <ser:addUser>'+
              '           <ser:userName>'+userdata.username+'</ser:userName>'+
              '           <ser:credential>'+userdata.password+'</ser:credential>'+
              '           <ser:roleList>Internal/subscriber</ser:roleList>'+
              '           <ser:claims>'+
              '              <xsd:claimURI>http://wso2.org/claims/givenname</xsd:claimURI>'+
              '              <xsd:value>'+userdata.fullname+'</xsd:value>'+
              '           </ser:claims>'+
              '           <ser:profileName>default</ser:profileName>'+
              '           <ser:requirePasswordChange>false</ser:requirePasswordChange>'+
              '        </ser:addUser>'+
              '     </soap:Body>'+
              '  </soap:Envelope>';
    var url ="https://192.168.11.9:9443/services/RemoteUserStoreManagerService.RemoteUserStoreManagerServiceHttpsSoap12Endpoint/";
    rest.post(url,{
        data:xml,
        username:wso2config.soap.auth.username,
        password:wso2config.soap.auth.password,
        headers:{
            "Content-type":'application/soap+xml;charset=UTF-8;action=\"urn:addUser\"'
        }
    }).on("complete",function(res){
        if(res==""){
          callback(null,{"success":"ok"})
          return;
        }
        xml = res.replace(/<([a-zA-Z0-9 ]+)(?:xml)ns=\".*\"(.*)>/g, "<$1$2>");
        
            
        xml2js.parseString(xml,function(err,result){
            try{
              if(result == null){
                callback(null,result["soapenv:Envelope"]["soapenv:Body"]);
                return true;
              }

              var fault = result["soapenv:Envelope"]["soapenv:Body"][0]["soapenv:Fault"];
              if(fault)
                  callback(fault[0]["soapenv:Reason"][0]["soapenv:Text"][0]["_"]);
              else callback("unknown Error");  
            }
            catch(e){
              callback(e);
            }
            
        })
        
    })
}
var checkUser = function(username,callback){
    soap.createClient(wsdl, function(err, client) {
        if (err) {
            callback(err);
            return;
        }
        var args = {
            username:username
        }
        client.setSecurity(new soap.BasicAuthSecurity(wso2config.soap.auth.username, wso2config.soap.auth.password));

        client.getUserId(args, function(erro, result) {
            if(erro){
                callback(erro);
            }
            else{
                var res ={};
                if(result.return == -1){
                    res.message = "User does not exist";
                    callback(null,res);
                }
                else{
                    res.message = "User exist";   
                    callback(res);
                }
            }
        });
    });
}
var getUserdata = function(opt, callback) {

}
module.exports = {
    register: register,
    checkUser:checkUser
}